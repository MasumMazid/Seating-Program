package com.cognixia.seatingProgram;

import java.io.IOException;

public class SeatingProgram {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String SeatPath="src\\SeatingChart.csv";
		MainMenu NewMenu = new MainMenu();
		NewMenu.TheMainMenu();
		
		//reservation test= new reservation();
		//test.saveReservation("a5", "hubba");
		//test.ViewList();
		
	}

}
